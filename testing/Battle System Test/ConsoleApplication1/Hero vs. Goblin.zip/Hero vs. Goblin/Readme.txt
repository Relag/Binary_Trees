A simple test of having 3 AI combatants and one player in a turn based fight.

Essentially there is a hero vector, a villian vector, and a master queue determining turn order.

Players use the up and down arrow keys to select someone to fight, and enter to confirm their selection.